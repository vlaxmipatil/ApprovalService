package com.example.approvalservice.validation;

import com.example.approvalservice.data.ApprovalRequest;
import com.example.approvalservice.exception.ApprovalException;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;


public class ValidationRulesTest {

    @Test(expected = ApprovalException.class)
    public void test_validate_ApprovalRequest_with_all_null_fields() throws Exception {
        ValidationRules validationRules = new ValidationRules();
        assertFalse(validationRules.validateApprovalRequest(new ApprovalRequest(null,null,null)));
    }

    @Test(expected = ApprovalException.class)
    public void test_validate_ApprovalRequest_with_null_request() throws Exception {
        ValidationRules validationRules = new ValidationRules();
        assertFalse(validationRules.validateApprovalRequest(null));
    }

    @Test(expected = ApprovalException.class)
    public void test_validate_ApprovalRequest_with_null_and_empty_fields() throws Exception {
        ValidationRules validationRules = new ValidationRules();
        assertFalse(validationRules.validateApprovalRequest(new ApprovalRequest("", "", null)));
    }

    @Test(expected = ApprovalException.class)
    public void test_validate_ApprovalRequest_with_null_quantity() throws Exception {
        ValidationRules validationRules = new ValidationRules();
        assertFalse(validationRules.validateApprovalRequest(new ApprovalRequest("Client1", "Security1", null)));
    }

    @Test
    public void test_validate_ApprovalRequest_with_zero_quantity() throws Exception {
        ValidationRules validationRules = new ValidationRules();
        assertTrue(validationRules.validateApprovalRequest(new ApprovalRequest("Client1", "Security1", new BigDecimal("0"))));
    }

    @Test
    public void test_validate_ApprovalRequest_with_valid_inputs() throws Exception {
        ValidationRules validationRules = new ValidationRules();
        assertTrue(validationRules.validateApprovalRequest(new ApprovalRequest("Client1", "Security1", new BigDecimal("1000"))));
    }

    }