package com.example.approvalservice.main;

import com.example.approvalservice.cache.ApprovalLimitCache;
import com.example.approvalservice.data.ApprovalRequest;
import com.example.approvalservice.exception.ApprovalException;
import com.example.approvalservice.service.ApprovalDecisionService;
import com.example.approvalservice.service.ApprovalResponseService;
import com.example.approvalservice.service.ApprovalSource;
import com.example.approvalservice.validation.ValidationRules;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingDeque;

import static org.junit.Assert.*;

public class ApprovalServiceControllerTest {

    @Test
    public void test_valid_input_is_processed_successfully_in_processRequest_method() throws Exception {
        ApprovalLimitCache cache = new ApprovalLimitCache();
        ApprovalServiceController controller = new ApprovalServiceController(cache);

        controller.init();
        assertTrue(controller.processRequest(new String[]{"Client1","Security1", "1000"}));
    }

    @Test
    public void test_invalid_input_is_processed_successfully_in_processRequest_method() throws Exception {
        ApprovalLimitCache cache = new ApprovalLimitCache();
        ApprovalServiceController controller = new ApprovalServiceController(cache);

        controller.init();
        assertFalse(controller.processRequest(new String[]{"Client1","", "1000"}));
    }

}