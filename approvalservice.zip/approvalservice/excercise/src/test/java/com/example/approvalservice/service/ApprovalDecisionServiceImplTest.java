package com.example.approvalservice.service;

import com.example.approvalservice.cache.ApprovalLimitCache;
import com.example.approvalservice.cache.Client;
import com.example.approvalservice.data.ApprovalRequest;
import com.example.approvalservice.data.ApprovalResponse;
import org.junit.Test;

import java.math.BigDecimal;

import static org.junit.Assert.*;


public class ApprovalDecisionServiceImplTest {
    @Test
    public void processRequest() throws Exception {
        ApprovalLimitCache cache = new ApprovalLimitCache();
        ApprovalDecisionService decisionService = new ApprovalDecisionServiceImpl(cache);

        cache.addApprovalLimitForClient(new Client("Client1", "Security1"), new BigDecimal(1000));
        cache.addApprovalLimitForClient(new Client("Client2", "Security1"), new BigDecimal(1000));

        ApprovalResponse response = decisionService.processRequest(new ApprovalRequest("Client1", "Security1",new BigDecimal("100")));
        assertEquals(response.getApprovedQuantity(), new BigDecimal("100"));

        ApprovalResponse response2 = decisionService.processRequest(new ApprovalRequest("Client1", "Security1",new BigDecimal("2000")));
        assertEquals(response2.getApprovedQuantity(), new BigDecimal("900"));

        ApprovalResponse response3 = decisionService.processRequest(new ApprovalRequest("Client2", "Security1",new BigDecimal("1000")));
        assertEquals(response3.getApprovedQuantity(), new BigDecimal("1000"));

    }

}