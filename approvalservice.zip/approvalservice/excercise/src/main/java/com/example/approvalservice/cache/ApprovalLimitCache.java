package com.example.approvalservice.cache;

import java.math.BigDecimal;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ApprovalLimitCache {
    // ConcurrentHashMap to store approved limit per client on given security
    private Map<Client, BigDecimal> approvalCache =new ConcurrentHashMap<>();

    public BigDecimal getApprovalLimitForClient(Client client){
        return approvalCache.get(client);
    }

    public void addApprovalLimitForClient(Client client, BigDecimal limitQuantity){
        approvalCache.put(client, limitQuantity);
    }

}
