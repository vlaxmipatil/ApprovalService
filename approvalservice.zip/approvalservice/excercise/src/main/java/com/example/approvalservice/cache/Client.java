package com.example.approvalservice.cache;

public class Client {
    private String client;
    private String secutiryId;

    public Client(String client, String secutiryId) {
        this.client = client;
        this.secutiryId = secutiryId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Client client1 = (Client) o;

        if (client != null ? !client.equals(client1.client) : client1.client != null) return false;
        return secutiryId != null ? secutiryId.equals(client1.secutiryId) : client1.secutiryId == null;

    }

    @Override
    public int hashCode() {
        int result = client != null ? client.hashCode() : 0;
        result = 31 * result + (secutiryId != null ? secutiryId.hashCode() : 0);
        return result;
    }
}
