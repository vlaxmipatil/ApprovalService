package com.example.approvalservice.data;

import java.math.BigDecimal;

public class ApprovalRequest {

    private final String client;
    private final String security;
    private final BigDecimal quantity;

    public ApprovalRequest(final String client, final String security, final BigDecimal quantity) {
        this.client = client;
        this.security = security;
        this.quantity = quantity;
    }

    public String getClient() {
        return client;
    }

    public String getSecurity() {
        return security;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ApprovalRequest{");
        sb.append("client='").append(client).append('\'');
        sb.append(", security='").append(security).append('\'');
        sb.append(", quantity=").append(quantity);
        sb.append('}');
        return sb.toString();
    }
}