package com.example.approvalservice.service;

import com.example.approvalservice.data.ApprovalRequest;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;

public class ApprovalSourceImpl implements ApprovalSource {

    BlockingQueue<ApprovalRequest> approvalRequestBlockingQueue = null;

    public ApprovalSourceImpl(BlockingQueue<ApprovalRequest> approvalRequestBlockingQueue) {
        this.approvalRequestBlockingQueue = approvalRequestBlockingQueue;
    }

    @Override
    public ApprovalRequest getNextApproval(){
        try {
           return approvalRequestBlockingQueue.take(); // this is blocking call. wait till next approval request is available
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<ApprovalRequest> getApprovalBatch(int maxSize) {
        List<ApprovalRequest> approvalRequestList = new ArrayList<>(maxSize);
        approvalRequestBlockingQueue.drainTo(approvalRequestList, maxSize);
        return approvalRequestList;
    }
}
