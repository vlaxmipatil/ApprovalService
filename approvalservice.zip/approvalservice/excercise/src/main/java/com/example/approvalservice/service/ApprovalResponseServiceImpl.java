package com.example.approvalservice.service;

import com.example.approvalservice.data.ApprovalResponse;

import java.util.List;

public class ApprovalResponseServiceImpl implements ApprovalResponseService {
    @Override
    public void sendResponse(ApprovalResponse response) {
        // implementation for sending the response back to the requestor
        System.out.println(Thread.currentThread().getName() + "Sending response :" + response);
    }

    @Override
    public void sendResponses(List<ApprovalResponse> responses) {
        // implementation of sending the response list back to the requestor
        System.out.println(Thread.currentThread().getName() + "Sending batch responses :" + responses);

    }
}
