package com.example.approvalservice.service;

import com.example.approvalservice.cache.ApprovalLimitCache;
import com.example.approvalservice.cache.Client;
import com.example.approvalservice.data.ApprovalRequest;
import com.example.approvalservice.data.ApprovalResponse;

import java.math.BigDecimal;

public class ApprovalDecisionServiceImpl implements ApprovalDecisionService {

    private ApprovalLimitCache cache;

    public ApprovalDecisionServiceImpl(ApprovalLimitCache cache) {
        this.cache = cache;
    }

    /**
     * The business implementation for processing the request based on available capital for given client.
     * 1. Get the available limit quantity from cache for give client +security
     * 2. If the quantity in request is less than the available quantity in cache, then approved quantity = requested quantity
     * 3. If the quantity in request is greater than available quantity in cache, then approved quantity = limit quantity in cache
     * NOTE:  This business logic may vary depending upon the business requirement. Here the approved quantity is calculated based on availability of approved amount.
     *
     * @param request
     * @return ApprovalResponse with approved quantity
     */
    @Override
    public ApprovalResponse processRequest(ApprovalRequest request) {

        String clientId = request.getClient();
        String security = request.getSecurity();
        Client client = new Client(clientId, security);
        BigDecimal limitQuantity = cache.getApprovalLimitForClient(client);
        BigDecimal approvedQuantity = new BigDecimal("0");
        if (limitQuantity != null) {
            if (request.getQuantity().compareTo(limitQuantity) <= 0) {
                approvedQuantity = request.getQuantity();
                //update the limitQuantity for the given client in the cache to reflect the new approved quantity out of the cache
                cache.addApprovalLimitForClient(client, limitQuantity.subtract(approvedQuantity));
            } else {
                approvedQuantity = limitQuantity;
            }
        }
        System.out.println(Thread.currentThread().getName() + "Approved quantity :" + approvedQuantity);
        return new ApprovalResponse(request, approvedQuantity);
    }
}
