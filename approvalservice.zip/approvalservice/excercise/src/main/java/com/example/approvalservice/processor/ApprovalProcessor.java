package com.example.approvalservice.processor;

import com.example.approvalservice.data.ApprovalRequest;
import com.example.approvalservice.data.ApprovalResponse;
import com.example.approvalservice.service.ApprovalDecisionService;
import com.example.approvalservice.service.ApprovalResponseService;
import com.example.approvalservice.service.ApprovalSource;

public class ApprovalProcessor implements Runnable {

    private ApprovalSource source;
    private ApprovalDecisionService decisionService;
    private ApprovalResponseService responseService;

    public ApprovalProcessor(final ApprovalSource source, final ApprovalDecisionService decisionService, final ApprovalResponseService responseService) {
        this.source = source;
        this.decisionService = decisionService;
        this.responseService = responseService;
    }

    public void run() {

        while (true) {
            try {
                ApprovalRequest request = source.getNextApproval();
                System.out.println(Thread.currentThread().getName() + " Processing ApprovalRequest:" + request);
                ApprovalResponse response = decisionService.processRequest(request);
                System.out.println(Thread.currentThread().getName() + " Processed request has ApprovalResponse:" + response);
                responseService.sendResponse(response);
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println(Thread.currentThread().getName() + " Error occurred while processing the approval request:" +e.getMessage());
            }
        }

    }

}