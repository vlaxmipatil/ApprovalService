package com.example.approvalservice.service;

import com.example.approvalservice.data.ApprovalRequest;
import com.example.approvalservice.data.ApprovalResponse;

public interface ApprovalDecisionService {
    ApprovalResponse processRequest(ApprovalRequest request);
}

