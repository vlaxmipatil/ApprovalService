package com.example.approvalservice.validation;

import com.example.approvalservice.data.ApprovalRequest;
import com.example.approvalservice.exception.ApprovalException;

import java.math.BigDecimal;

public class ValidationRules {

    /**
     * Validates ApprovalRequest. Returns true if the request is valid
     * 1. If request is null - throw custom exception
     * 2. If request with invalid quantity (0 or null is considered invalid quantity)- throw custom exception
     * 3. If client information not present in request - throw custom exception
     * 4. If security information not present in request - throw custom exception
     * 5. Otherwise return true;
     *  NOTE - More validations can be added here for input entries
     * @param request
     * @return true if validation is successful
     * @throws ApprovalException if invalid inputs
     */
    public boolean validateApprovalRequest(ApprovalRequest request) throws ApprovalException {
        if(request == null){
            throw new ApprovalException("Request is empty");
        }
        if(request.getQuantity() == null || request.getQuantity().compareTo(BigDecimal.ZERO) < 0  ){
            throw new ApprovalException("Invalid quantity in ApprovalRequest");
        }
        if(request.getClient() == null || request.getClient().isEmpty()){
            throw new ApprovalException("Client information missing on the ApprovalRequest");
        }
        if(request.getSecurity() == null || request.getSecurity().isEmpty()){
            throw new ApprovalException("Security information missing on the ApprovalRequest");
        }
        /**
         * Only basic validations are done currently in this method.
         * More validations could be added depending on business requirements. Depending upon the rules this method would return true,false or throw exception
         */

        return true;
    }
}
