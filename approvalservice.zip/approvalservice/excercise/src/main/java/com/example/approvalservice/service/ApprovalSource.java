package com.example.approvalservice.service;

import com.example.approvalservice.data.ApprovalRequest;

import java.util.List;

public interface ApprovalSource{

    /**
     * Get the next approval request. This will block until an approval
     * <p>
     * request arrives.
     */

    ApprovalRequest getNextApproval();


    /**
     * Get any queued approval requests (up to <code>maxSize</code>).
     * <p>
     * This will
     * <p>
     * return immediately even if there are no waiting approval
     * <p>
     * requests.
     *
     * @param maxSize maximum number of approvals requests to receive.
     */

    List<ApprovalRequest> getApprovalBatch(int maxSize);

}