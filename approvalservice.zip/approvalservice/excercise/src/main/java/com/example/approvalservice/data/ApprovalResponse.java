package com.example.approvalservice.data;

import java.math.BigDecimal;

public class ApprovalResponse {

    private final ApprovalRequest request;
    private final BigDecimal approvedQuantity;

    public ApprovalResponse(final ApprovalRequest request, final BigDecimal approvedQuantity) {
        this.request = request;
        this.approvedQuantity = approvedQuantity;
    }

    public ApprovalRequest getRequest() {
        return request;
    }

    public BigDecimal getApprovedQuantity() {
        return approvedQuantity;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ApprovalResponse{");
        sb.append("request=").append(request);
        sb.append(", approvedQuantity=").append(approvedQuantity);
        sb.append('}');
        return sb.toString();
    }
}