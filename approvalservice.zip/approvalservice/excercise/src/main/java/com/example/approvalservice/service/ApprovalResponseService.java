package com.example.approvalservice.service;


import com.example.approvalservice.data.ApprovalResponse;

import java.util.List;

public interface ApprovalResponseService{

    void sendResponse(ApprovalResponse response);

    void sendResponses(List<ApprovalResponse> responses);

}