package com.example.approvalservice.main;


import com.example.approvalservice.cache.ApprovalLimitCache;
import com.example.approvalservice.cache.Client;

import java.math.BigDecimal;
import java.util.Scanner;

public class ApprovalServiceBootstrap {

    public static void main(String args[]) {

        Thread.setDefaultUncaughtExceptionHandler((t, e) -> System.out.println("Error occurred in Approval service." + e));

        try {
            System.out.println("Approval Service Starting");
            ApprovalLimitCache cache = new ApprovalLimitCache();
            // Add some data to the cache which will be used to for testing. Real time application would populate this data differently and add it to the cache.
            cache.addApprovalLimitForClient(new Client("Client1", "Security1"), new BigDecimal(1000000000));
            cache.addApprovalLimitForClient(new Client("Client2", "Security1"), new BigDecimal(1000000000));
            cache.addApprovalLimitForClient(new Client("Client3", "Security2"), new BigDecimal(1000000000));
            cache.addApprovalLimitForClient(new Client("Client1", "Security2"), new BigDecimal(1000000000));
            cache.addApprovalLimitForClient(new Client("Client2", "Security2"), new BigDecimal(1000000000));

            ApprovalServiceController approvalServiceController = new ApprovalServiceController(cache);
            approvalServiceController.init();

            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter input in format :Client Security Quantity");

            while (true) {
                String line = scanner.nextLine();
                String[] inputs = line.split(" ");
                if (inputs.length == 3) {
                    approvalServiceController.processRequest(inputs);
                } else {
                    System.out.println("Invalid input. Please enter input in format -'Client Security Quantity' ");
                }
            }
        }catch (Exception e) {
            System.out.println("Error while starting Approval service."+ e);
            System.exit(-1);
        }
    }
}
