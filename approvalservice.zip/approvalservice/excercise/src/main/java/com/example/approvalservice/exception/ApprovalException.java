package com.example.approvalservice.exception;

public class ApprovalException extends Exception {

    public ApprovalException(String message){
        super(message);
    }
}
