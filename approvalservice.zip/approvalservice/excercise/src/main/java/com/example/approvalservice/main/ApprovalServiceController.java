package com.example.approvalservice.main;

import com.example.approvalservice.cache.ApprovalLimitCache;
import com.example.approvalservice.data.ApprovalRequest;
import com.example.approvalservice.exception.ApprovalException;
import com.example.approvalservice.processor.ApprovalProcessor;
import com.example.approvalservice.service.ApprovalDecisionService;
import com.example.approvalservice.service.ApprovalDecisionServiceImpl;
import com.example.approvalservice.service.ApprovalResponseService;
import com.example.approvalservice.service.ApprovalResponseServiceImpl;
import com.example.approvalservice.service.ApprovalSource;
import com.example.approvalservice.service.ApprovalSourceImpl;
import com.example.approvalservice.validation.ValidationRules;

import java.math.BigDecimal;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

public class ApprovalServiceController {

    private ApprovalLimitCache cache;
    private BlockingQueue<ApprovalRequest> queue;
    private ApprovalSource approvalSource;
    private ApprovalDecisionService decisionService;
    private ApprovalResponseService responseService;
    private ExecutorService executor;
    private ValidationRules validationRules;

    public ApprovalServiceController(ApprovalLimitCache cache) {
        this.cache = cache;
    }

    void init() {
        queue = new LinkedBlockingQueue<>();
        approvalSource = new ApprovalSourceImpl(queue);
        decisionService = new ApprovalDecisionServiceImpl(cache);
        responseService = new ApprovalResponseServiceImpl();
        validationRules = new ValidationRules();
        executor = Executors.newFixedThreadPool(4);
    }



    /**
     * Generate the ApprovalRequest based on inputs.
     * Validate the request against given Validation rules.
     * Add the request to blocking queue for processing by ApprovalSourceImpl.
     * Submit a task to threadpoolexecutor
     *
     * @param inputs
     */
    public boolean processRequest(String[] inputs) {
        String client = inputs[0];
        String security = inputs[1];
        try {
            BigDecimal quantity = new BigDecimal(inputs[2]);
            ApprovalRequest request = new ApprovalRequest(client, security, quantity);
            if (validationRules.validateApprovalRequest(request)) {
                System.out.println("Validation passed for given input:" + request);
                queue.put(request);
            } else {
                System.out.println("Validation failed for given input:" + request);
                return false;
            }
        } catch (ApprovalException e) {
            e.printStackTrace();
            return false;

        } catch (InterruptedException e) {
            e.printStackTrace();
            return false;
        }
        executor.execute(new ApprovalProcessor(approvalSource, decisionService, responseService));
        return true;
    }
}
